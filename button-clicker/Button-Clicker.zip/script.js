
function addShawdow(element){
    element.classList.add("shawdow");
}

function removeShawdow(element){
    element.classList.remove("shawdow");
}

function logout(element){
    element.innerText = "Logout";
}

function windowPopUp(){
    alert("Ninja was Liked");
}

function disapear(element){
    element.remove();
}